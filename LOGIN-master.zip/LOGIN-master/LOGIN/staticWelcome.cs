﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LOGIN
{
    internal class staticWelcome
    {
        public static string name="";
        public static string role="";
        public static string email = "";
        public static string tempId = "";
    }
}
